package com.sely.launcher.sidebar

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.appmanagement.FavoritesStore
import com.sely.launcher.theme.ThemeManager

/**
 * Real drag-to-reorder (via `ItemTouchHelper`, the standard
 * `RecyclerView` reordering mechanism) and remove for Smart Sidebar's
 * Favorites row. Reordering/removing writes straight through to
 * `FavoritesStore`, the same store App Management's favorite toggle
 * already uses — one real list, not a sidebar-only copy of it.
 */
class SidebarFavoriteAdapter(
    private val context: Context,
    private var apps: MutableList<AppInfo>,
    private var editMode: Boolean,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<SidebarFavoriteAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.favIcon)
        val label: TextView = view.findViewById(R.id.favLabel)
        val remove: ImageView = view.findViewById(R.id.favRemove)
    }

    val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
    ) {
        override fun onMove(rv: RecyclerView, holder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
            val from = holder.bindingAdapterPosition
            val to = target.bindingAdapterPosition
            if (from < 0 || to < 0) return false
            val moved = apps.removeAt(from)
            apps.add(to, moved)
            notifyItemMoved(from, to)
            FavoritesStore.moveFavorite(context, from, to)
            return true
        }
        override fun onSwiped(holder: RecyclerView.ViewHolder, direction: Int) {}
        override fun isLongPressDragEnabled() = editMode
    })

    fun setEditMode(enabled: Boolean) {
        editMode = enabled
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_sidebar_favorite, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.remove.visibility = if (editMode) View.VISIBLE else View.GONE
        holder.remove.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos < 0) return@setOnClickListener
            FavoritesStore.removeFavorite(context, apps[pos].packageName)
            apps.removeAt(pos)
            notifyItemRemoved(pos)
        }
        holder.itemView.setOnClickListener {
            if (!editMode) onClick(app)
        }
        holder.itemView.setOnLongClickListener {
            if (!editMode) setEditMode(true)
            touchHelper.startDrag(holder)
            true
        }
    }
}
