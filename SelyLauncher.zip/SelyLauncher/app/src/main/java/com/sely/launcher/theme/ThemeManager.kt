package com.sely.launcher.theme

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.View
import com.sely.launcher.R

/**
 * Sely Theme Engine (spec section 10), core slice.
 *
 * Real persistence (SharedPreferences — 🟢, no permission needed) for:
 *  - accent color (used to tint icons/highlights everywhere)
 *  - dark/light mode (used for background/surface/text colors)
 *
 * This is deliberately a plain getter/setter object rather than a
 * generic "recolor every view via reflection" trick — each screen calls
 * these getters explicitly in its own onCreate/onResume (see
 * MainActivity, ControlCenterActivity, SidebarActivity,
 * AppDrawerActivity for the pattern). That's a few lines of real,
 * traceable code per screen instead of a fragile generic hack, and it's
 * the same pattern to extend to every remaining screen as new modules
 * are added — see README.
 *
 * Not yet built: icon shape (square/circle/squircle — needs a custom
 * icon-masking step in AppGridAdapter), custom fonts, per-app icon
 * overrides, wallpaper-based dynamic accent extraction (would use
 * Android's Palette library against the current wallpaper bitmap).
 */
object ThemeManager {

    private const val PREFS = "sely_theme"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_DARK = "dark_mode"

    enum class Preset(val label: String, val colorRes: Int) {
        SELY_BLUE("Sely Blue", R.color.sely_accent_blue_preset),
        SELY_NEON("Sely Neon", R.color.sely_accent_neon),
        SELY_PURPLE("Sely Purple", R.color.sely_accent_purple_preset)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun accentColor(context: Context): Int {
        val default = context.getColor(R.color.sely_accent_blue_preset)
        return prefs(context).getInt(KEY_ACCENT, default)
    }

    fun setAccentColor(context: Context, color: Int) {
        prefs(context).edit().putInt(KEY_ACCENT, color).apply()
    }

    fun isDark(context: Context): Boolean = prefs(context).getBoolean(KEY_DARK, true)

    fun setDark(context: Context, dark: Boolean) {
        prefs(context).edit().putBoolean(KEY_DARK, dark).apply()
    }

    fun backgroundColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_bg_deep else R.color.sely_bg_light)

    fun surfaceGlassColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_surface_glass else R.color.sely_surface_glass_light)

    fun dockColor(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_dock_bg else R.color.sely_dock_bg_light)

    fun textPrimary(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_text_primary else R.color.sely_text_primary_light)

    fun textSecondary(context: Context): Int =
        context.getColor(if (isDark(context)) R.color.sely_text_secondary else R.color.sely_text_secondary_light)

    // ------------------------------------------------------------------
    // Sely visual style helpers (glass cards, gradient screens, glow).
    // Screens call these instead of setBackgroundColor(...) so rounded
    // glass shapes are not flattened into a plain rectangle.
    // ------------------------------------------------------------------

    private fun dpToPx(context: Context, dp: Float): Float =
        dp * context.resources.displayMetrics.density

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha shl 24)

    /** Full-screen background: deep blue/black with a soft purple corner. */
    fun screenBackground(context: Context): Drawable {
        if (!isDark(context)) return ColorDrawable(context.getColor(R.color.sely_bg_light))
        val d = GradientDrawable()
        d.setOrientation(GradientDrawable.Orientation.TL_BR)
        d.setColors(
            intArrayOf(
                Color.parseColor("#FF050814"),
                Color.parseColor("#FF0A1533"),
                Color.parseColor("#FF160B33")
            )
        )
        return d
    }

    /** Translucent scrim used on Home so the real wallpaper shows through. */
    fun homeScrim(context: Context): Drawable {
        val d = GradientDrawable()
        d.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM)
        d.setColors(
            intArrayOf(
                context.getColor(R.color.sely_scrim_top),
                context.getColor(R.color.sely_scrim_mid),
                context.getColor(R.color.sely_scrim_bottom)
            )
        )
        return d
    }

    /** Rounded glass card with a subtle accent-colored glow outline. */
    fun glassDrawable(context: Context, radiusDp: Float = 22f): Drawable {
        val d = GradientDrawable()
        d.setShape(GradientDrawable.RECTANGLE)
        d.setCornerRadius(dpToPx(context, radiusDp))
        val strokePx = dpToPx(context, 1f).toInt().coerceAtLeast(1)
        if (isDark(context)) {
            d.setOrientation(GradientDrawable.Orientation.TL_BR)
            d.setColors(
                intArrayOf(Color.parseColor("#CC1B2A55"), Color.parseColor("#CC130F33"))
            )
            d.setStroke(strokePx, withAlpha(accentColor(context), 0x66))
        } else {
            d.setColor(context.getColor(R.color.sely_surface_glass_light))
            d.setStroke(strokePx, Color.parseColor("#22000000"))
        }
        return d
    }

    fun applyScreenBackground(view: View) {
        view.background = screenBackground(view.context)
    }

    fun applyGlass(view: View, radiusDp: Float = 22f) {
        view.background = glassDrawable(view.context, radiusDp)
    }

    fun applyDock(view: View) {
        view.background = glassDrawable(view.context, 32f)
    }

    // ------------------------------------------------------------------
    // iOS-style surfaces — additive, used only by the screens being
    // given the "premium iPhone" redesign (see each layout's own
    // comments for which). Existing glassDrawable/screenBackground
    // above are untouched and still used by every other screen exactly
    // as before, so nothing already working changes.
    //
    // Still honors the user's own Theme Engine settings: isDark() for
    // light/dark, accentColor() for tint — this is a different *shape*
    // language (flat, hairline-separated, iOS-style elevation) on top
    // of the same real settings, not a separate theme system.
    // ------------------------------------------------------------------

    /** Flat iOS systemBackground color, for call sites that need an Int rather than a Drawable. */
    fun iosBackgroundColor(context: Context): Int =
        if (isDark(context)) Color.parseColor("#FF000000") else Color.parseColor("#FFF2F2F7")

    /** Solid iOS systemBackground-style screen fill — flat, not a glow gradient. */
    fun iosBackgroundDrawable(context: Context): Drawable = ColorDrawable(iosBackgroundColor(context))

    fun applyIosBackground(view: View) {
        view.background = iosBackgroundDrawable(view.context)
    }

    /** iOS "grouped" card: flat elevated surface, hairline border, no glow. */
    fun iosCardDrawable(context: Context, radiusDp: Float = 20f): Drawable {
        val d = GradientDrawable()
        d.setShape(GradientDrawable.RECTANGLE)
        d.setCornerRadius(dpToPx(context, radiusDp))
        val strokePx = dpToPx(context, 1f).toInt().coerceAtLeast(1)
        if (isDark(context)) {
            d.setColor(Color.parseColor("#FF1C1C1E"))
            d.setStroke(strokePx, Color.parseColor("#FF2C2C2E"))
        } else {
            d.setColor(Color.parseColor("#FFFFFFFF"))
            d.setStroke(strokePx, Color.parseColor("#1F000000"))
        }
        return d
    }

    fun applyIosCard(view: View, radiusDp: Float = 20f) {
        view.background = iosCardDrawable(view.context, radiusDp)
    }

    /** Fully-rounded iOS pill (search bars, dock) — same flat surface, pill-shaped. */
    fun iosPillDrawable(context: Context): Drawable = iosCardDrawable(context, 999f)

    fun applyIosPill(view: View) {
        view.background = iosPillDrawable(view.context)
    }

    /** iOS secondary surface used inside a card for a nested control (e.g. an icon tile). */
    fun iosInsetDrawable(context: Context, radiusDp: Float = 14f): Drawable {
        val d = GradientDrawable()
        d.setShape(GradientDrawable.RECTANGLE)
        d.setCornerRadius(dpToPx(context, radiusDp))
        d.setColor(if (isDark(context)) Color.parseColor("#FF2C2C2E") else Color.parseColor("#FFF2F2F7"))
        return d
    }

    fun applyIosInset(view: View, radiusDp: Float = 14f) {
        view.background = iosInsetDrawable(view.context, radiusDp)
    }
}
