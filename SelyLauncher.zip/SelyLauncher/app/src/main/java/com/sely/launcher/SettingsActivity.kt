package com.sely.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.controlcenter.ControlCenterActivity
import com.sely.launcher.dashboard.DeviceDashboardActivity
import com.sely.launcher.databinding.ActivitySettingsBinding
import com.sely.launcher.drawer.AppDrawerActivity
import com.sely.launcher.multitask.MultitaskHubActivity
import com.sely.launcher.notifications.NotificationCenterActivity
import com.sely.launcher.notifications.SelyNotificationListenerService
import com.sely.launcher.sidebar.SidebarActivity
import com.sely.launcher.theme.ThemeActivity
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Settings (spec section 45) — real menu, not a stub.
 *
 * Two kinds of row:
 *  1. Navigation rows that just open a screen already built
 *     (Themes, Device Dashboard, Recents, App Drawer, Control Center,
 *     Notification Center).
 *  2. Live permission-status rows: subtitle reflects the actual current
 *     grant state (checked fresh in onResume, since the user may have
 *     just come back from the system settings screen it links to) and
 *     the row itself opens the real system screen to change it — same
 *     pattern used throughout Control Center/Dashboard.
 *
 * Rebuilds its row list in onResume so returning from any linked screen
 * (e.g. just granted Notification access) shows the updated status
 * immediately, matching how every other screen here stays live.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        // Sely Privacy Center's Launcher PIN (see PrivacyLockStore):
        // while Guest Space is active, Settings is the main escape hatch
        // back to full access, so it's the one real place this launcher
        // enforces the PIN it collected.
        val guestActive = com.sely.launcher.privacy.GuestModeStore.isActive(this)
        val pinSet = com.sely.launcher.privacy.PrivacyLockStore.hasPin(this)
        if (guestActive && pinSet) {
            com.sely.launcher.privacy.LockGate.unlock(
                this,
                screenName = "Settings",
                onSuccess = { unlocked = true; applyTheme(); rebuildRows() },
                onCancel = { finish() }
            )
        } else {
            unlocked = true
        }
    }

    override fun onResume() {
        super.onResume()
        if (!unlocked) return
        applyTheme()
        rebuildRows()
    }

    private fun applyTheme() {
        ThemeManager.applyIosBackground(binding.settingsRoot)
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
    }

    private fun rebuildRows() {
        // Remove everything except the title (index 0)
        while (binding.settingsContainer.childCount > 1) {
            binding.settingsContainer.removeViewAt(1)
        }

        addSectionHeader("Appearance")
        addRow("Themes", "Accent color, dark / light mode") {
            startActivity(Intent(this, ThemeActivity::class.java))
        }
        addRow("Wallpaper", "Pick, blur/dim, separate Home & Lock, daily rotation") {
            startActivity(Intent(this, com.sely.launcher.wallpaper.WallpaperActivity::class.java))
        }
        addRow("Clock Style", "Digital, Large, Minimal, Vertical, or Analog") {
            startActivity(Intent(this, com.sely.launcher.clock.ClockPickerActivity::class.java))
        }
        addRow("Performance", "Battery, Balanced, or Performance mode") {
            startActivity(Intent(this, com.sely.launcher.performance.PerformanceActivity::class.java))
        }

        addSectionHeader("Launcher")
        addRow("Command Center", "Live stats and every Sely screen in one place") {
            startActivity(Intent(this, com.sely.launcher.commandcenter.CommandCenterActivity::class.java))
        }
        addRow("App Management", "All apps: version, size, hide, favorite, pin shortcut, uninstall") {
            startActivity(Intent(this, com.sely.launcher.appmanagement.AppManagementActivity::class.java))
        }
        addRow("Game Mode", "DND, screenshot/record shortcuts, and tag your games") {
            startActivity(Intent(this, com.sely.launcher.gamemode.GameModeActivity::class.java))
        }
        addRow("Modes", "Normal, Gaming, Study, Work, Night, Battery Saver, or your own") {
            startActivity(Intent(this, com.sely.launcher.modes.ModesActivity::class.java))
        }
        addRow("Privacy Center", "Permissions, launcher PIN, Guest Space, hidden apps") {
            startActivity(Intent(this, com.sely.launcher.privacy.PrivacyCenterActivity::class.java))
        }
        addRow("App Pairs", "Save two apps, launch together — real split screen on supported devices") {
            startActivity(Intent(this, com.sely.launcher.apppairs.AppPairsActivity::class.java))
        }
        addRow("Desktop Mode", "Opens a desktop-style Home on a connected external display") {
            com.sely.launcher.desktopmode.DesktopModeLauncher.launch(this)
        }
        addRow("Floating Bubble", bubbleStatus()) { onBubbleRowTapped() }
        addRow("Smart Sidebar", sidebarStatus()) { onSidebarRowTapped() }
        addRow("Smart Sidebar: position, size & transparency", "") {
            startActivity(Intent(this, com.sely.launcher.sidebar.SmartSidebarSettingsActivity::class.java))
        }
        addRow("Search", "Apps, settings shortcuts, and contacts") {
            startActivity(Intent(this, com.sely.launcher.search.SearchActivity::class.java))
        }
        addRow("App Drawer", "Search and browse all apps") {
            startActivity(Intent(this, AppDrawerActivity::class.java))
        }
        addRow("Control Center", "Quick toggles, volume, brightness") {
            startActivity(Intent(this, ControlCenterActivity::class.java))
        }
        addRow("Notification Center", "View and manage notifications") {
            startActivity(Intent(this, NotificationCenterActivity::class.java))
        }
        addRow("Sidebar", "Favorites and tools — swipe from the right edge on Home") {
            startActivity(Intent(this, SidebarActivity::class.java))
        }
        addRow("Multitasking", "Apps opened through Sely, most recent and most used") {
            startActivity(Intent(this, MultitaskHubActivity::class.java))
        }
        addRow("Clipboard", "Clips Sely has seen while open, pin your favorites") {
            startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
        }
        addRow("File Hub", "Images, videos, audio, downloads") {
            startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
        }
        addRow("QR / Barcode Scanner", "Scan codes with the camera") {
            startActivity(Intent(this, com.sely.launcher.qrscanner.QrScannerActivity::class.java))
        }
        addRow("Screenshot Studio", "Crop, draw, add text, blur — edit any image") {
            startActivity(Intent(this, com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java))
        }
        addRow("Screen Recorder", "Record your screen, with recording history") {
            startActivity(Intent(this, com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java))
        }
        addRow("Network Center", "Connection status, Wi-Fi, Bluetooth, mobile data") {
            startActivity(Intent(this, com.sely.launcher.network.NetworkCenterActivity::class.java))
        }
        addRow("Sound & Haptics", "App sounds, touch vibration, charging sound") {
            startActivity(Intent(this, com.sely.launcher.soundhaptics.SoundHapticsActivity::class.java))
        }
        addRow("Battery & Device", "Battery, RAM, storage, device info") {
            startActivity(Intent(this, DeviceDashboardActivity::class.java))
        }

        addSectionHeader("Privacy & Permissions")
        val notifGranted = SelyNotificationListenerService.isEnabled(this)
        addRow("Notification access", if (notifGranted) "Granted" else "Not granted — tap to grant") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        val writeGranted = Settings.System.canWrite(this)
        addRow("Modify system settings", if (writeGranted) "Granted (used for Brightness slider)" else "Not granted — tap to grant") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        addRow("Default launcher", defaultLauncherStatus(), opensDefaultAppsSettings = true)

        addSectionHeader("About")
        addRow(getString(R.string.app_name), getString(R.string.tagline)) { }
    }

    /** Live status line: overlay permission + whether the bubble service is on. */
    private fun bubbleStatus(): String {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            return "Not granted — tap to allow it to float over other apps"
        }
        return if (com.sely.launcher.bubble.BubblePrefs.isRunning(this)) {
            "Running — tap to turn off"
        } else {
            "Tap to turn on"
        }
    }

    private fun onBubbleRowTapped() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            android.widget.Toast.makeText(this, "Grant the permission, then come back and tap again", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, com.sely.launcher.bubble.FloatingBubbleService::class.java)
        if (com.sely.launcher.bubble.BubblePrefs.isRunning(this)) {
            serviceIntent.action = com.sely.launcher.bubble.FloatingBubbleService.ACTION_STOP
            startService(serviceIntent)
        } else {
            androidx.core.content.ContextCompat.startForegroundService(this, serviceIntent)
        }
        rebuildRows()
    }

    private fun sidebarStatus(): String {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            return "Not granted — tap to allow it to float over other apps"
        }
        return if (com.sely.launcher.sidebar.SmartSidebarPrefs.isRunning(this)) {
            "Running — tap to turn off"
        } else {
            "Tap to turn on"
        }
    }

    private fun onSidebarRowTapped() {
        if (!android.provider.Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            android.widget.Toast.makeText(this, "Grant the permission, then come back and tap again", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, com.sely.launcher.sidebar.SmartSidebarService::class.java)
        if (com.sely.launcher.sidebar.SmartSidebarPrefs.isRunning(this)) {
            serviceIntent.action = com.sely.launcher.sidebar.SmartSidebarService.ACTION_STOP
            startService(serviceIntent)
        } else {
            androidx.core.content.ContextCompat.startForegroundService(this, serviceIntent)
        }
        rebuildRows()
    }

    /** Real check: resolves who Android currently treats as the default Home app. */
    private fun defaultLauncherStatus(): String {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = packageManager.resolveActivity(homeIntent, 0)
        return if (resolved?.activityInfo?.packageName == packageName) {
            "Sely is your default Home app"
        } else {
            "Not set as default — tap to choose"
        }
    }

    private fun addRow(label: String, subtitle: String, opensDefaultAppsSettings: Boolean = false, onClick: (() -> Unit)? = null) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_settings_row, binding.settingsContainer, false)
        val labelView = row.findViewById<TextView>(R.id.rowLabel)
        val subtitleView = row.findViewById<TextView>(R.id.rowSubtitle)
        labelView.text = label
        subtitleView.text = subtitle
        labelView.setTextColor(ThemeManager.textPrimary(this))
        subtitleView.setTextColor(ThemeManager.textSecondary(this))
        row.setOnClickListener {
            if (opensDefaultAppsSettings) {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } else {
                onClick?.invoke()
            }
        }
        binding.settingsContainer.addView(row)
    }

    private fun addSectionHeader(title: String) {
        val header = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(ThemeManager.accentColor(this@SettingsActivity))
            setPadding(0, dp(20), 0, dp(8))
        }
        binding.settingsContainer.addView(header)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
